<?php

/**************************************
WIDGET: belle_about
***************************************/

	add_action('widgets_init', 'register_widget_belle_about' );
	function register_widget_belle_about () {
		register_widget('belle_about');	
	}

	class belle_about extends WP_Widget {

		/**************************************
		1. INIT
		***************************************/
		function __construct () {

				$widget_ops = array(
					'classname' => 'belle_about', 								
					'description' => esc_html__('Information about the owner/author of the blog.', "loc-belle-widgets-plugin")	 				
				);
				$control_ops = array(
					'width' => 300, 
					'height' => 350, 
					'id_base' => 'belle_about' 														
				);

				parent::__construct('belle_about', esc_html__('Belle: About', "loc-belle-widgets-plugin"), $widget_ops, $control_ops );	
		}

		/**************************************
		2. UPDATE
		***************************************/
		function update($new_instance, $old_instance) {
			return $new_instance;	 
		}

		/**************************************
		3. FORM
		***************************************/
		function form($instance) {

			$canon_options = get_option('canon_options'); 

			// set read-more-text default
			$read_more_text = (empty($canon_options['read_more_text'])) ? esc_html__('Read More', "loc-belle-widgets-plugin") : wp_kses_post($canon_options['read_more_text']);

			// defaults
			$defaults = array( 
				'title' 				=> esc_html__('About Me', "loc-belle-widgets-plugin"),
				'name' 					=> esc_html__('Belle Wilson', "loc-belle-widgets-plugin"),
				'tagline' 				=> esc_html__('Wife / Blogger / Amateur Photographer', "loc-belle-widgets-plugin"),
				'description' 			=> esc_html__('Cras justo odio, dapibus ac facilisis in, egestas egem sociis natoque perient montes, nascetur ridiculus mus.', "loc-belle-widgets-plugin"),
				'read_more_text' 		=> $read_more_text,
				'read_more_link' 		=> esc_url('http://www.google.com'),
			);

			$instance = wp_parse_args($instance, $defaults);
			extract($instance);

			$users = get_users();

			?>

			<!-- TEXT -->	
				<p>
					<label for="<?php echo esc_attr($this->get_field_id('title')); ?> "><?php esc_html_e("Title", "loc-belle-widgets-plugin"); ?>: </label><br>
					<input type='text' id='<?php echo esc_attr($this->get_field_id('title')); ?>' name='<?php echo esc_attr($this->get_field_name('title')); ?>' value="<?php if(isset($title)) echo htmlspecialchars($title); ?>">
				</p>


			<!-- UPLOAD -->	
				<p>
					<label for="<?php echo esc_attr($this->get_field_id('image_url')); ?> "><?php esc_html_e("Image URL", "loc-belle-widgets-plugin"); ?>: </label><br>
					<input type='text' id='<?php echo esc_attr($this->get_field_id('image_url')); ?>' name='<?php echo esc_attr($this->get_field_name('image_url')); ?>' value="<?php if(isset($image_url)) echo htmlspecialchars($image_url); ?>">
					<input type="button" class="upload button upload_button" value="<?php esc_html_e('Select'); ?>" />
				</p>

			<!-- TEXT -->	
				<p>
					<label for="<?php echo esc_attr($this->get_field_id('name')); ?> "><?php esc_html_e("Name", "loc-belle-widgets-plugin"); ?>: </label><br>
					<input type='text' id='<?php echo esc_attr($this->get_field_id('name')); ?>' name='<?php echo esc_attr($this->get_field_name('name')); ?>' value="<?php if(isset($name)) echo htmlspecialchars($name); ?>">
				</p>

			<!-- TEXT -->	
				<p>
					<label for="<?php echo esc_attr($this->get_field_id('tagline')); ?> "><?php esc_html_e("Tagline", "loc-belle-widgets-plugin"); ?>: </label><br>
					<input type='text' id='<?php echo esc_attr($this->get_field_id('tagline')); ?>' name='<?php echo esc_attr($this->get_field_name('tagline')); ?>' value="<?php if(isset($tagline)) echo htmlspecialchars($tagline); ?>">
				</p>

			<!-- TEXTAREA -->	
				<p>
					<label for='<?php echo esc_attr($this->get_field_id('description')); ?>'><?php esc_html_e("Description", "loc-belle-widgets-plugin"); ?></label><br>
					<textarea class='widefat' id='<?php echo esc_attr($this->get_field_id('description')); ?>' name='<?php echo esc_attr($this->get_field_name('description')); ?>' rows='5'><?php if (isset($description)) echo esc_attr($description); ?></textarea>
				</P>

			<!-- TEXT -->	
				<p>
					<label for="<?php echo esc_attr($this->get_field_id('read_more_text')); ?> "><?php esc_html_e("Read More text", "loc-belle-widgets-plugin"); ?>: </label><br>
					<input type='text' id='<?php echo esc_attr($this->get_field_id('read_more_text')); ?>' name='<?php echo esc_attr($this->get_field_name('read_more_text')); ?>' value="<?php if(isset($read_more_text)) echo htmlspecialchars($read_more_text); ?>">
				</p>

			<!-- TEXT -->	
				<p>
					<label for="<?php echo esc_attr($this->get_field_id('read_more_link')); ?> "><?php esc_html_e("Read More link", "loc-belle-widgets-plugin"); ?>: </label><br>
					<input type='text' id='<?php echo esc_attr($this->get_field_id('read_more_link')); ?>' name='<?php echo esc_attr($this->get_field_name('read_more_link')); ?>' value="<?php if(isset($read_more_link)) echo htmlspecialchars($read_more_link); ?>">
				</p>

			<!-- DYNAMIC SELECT -->	
				<p>	
					<label for="<?php echo esc_attr($this->get_field_id('user_id')); ?> "><?php esc_html_e("Display social links belonging to user:", "loc-belle-widgets-plugin"); ?>:</label><br>
					<select name="<?php echo esc_attr($this->get_field_name('user_id')); ?>">
						<option value="off"><?php esc_html_e('Off', 'loc-belle-widgets-plugin'); ?></option>
						<option value="off">---</option>
						<?php 

							foreach ($users as $key => $user) {
							?>
		     					<option value="<?php echo esc_attr($user->ID); ?>" <?php if (isset($user_id)) {if ($user_id == $user->ID) echo "selected='selected'";} ?>><?php echo esc_attr($user->data->display_name); ?></option> 
							<?php
							}

						?> 
					</select> 
				</p>

			<?php
		}

		/**************************************
		4. DISPLAY
		***************************************/
		function widget($args, $instance) {

			// DEFAULTS
			$instance = array_merge(array(
				'title' 				=> esc_html__('About Me', "loc-belle-widgets-plugin"),
				'name' 					=> esc_html__('Belle Wilson', "loc-belle-widgets-plugin"),
				'tagline' 				=> esc_html__('Wife / Blogger / Amateur Photographer', "loc-belle-widgets-plugin"),
				'description' 			=> esc_html__('Cras justo odio, dapibus ac facilisis in, egestas egem sociis natoque perient montes, nascetur ridiculus mus.', "loc-belle-widgets-plugin"),
				'read_more_text' 		=> esc_html__('Read More', "loc-belle-widgets-plugin"),
				'read_more_link' 		=> esc_url('http://www.google.com'),
			), $instance);
			
			extract($args);								
			extract($instance);							

 			// EMPTY WIDGET ID FAILSAIFE (WHEN WIDGET IS USED AS VC ELEMENT)
			if (!isset($widget_id)) { $widget_id = "belle_about-" . uniqid(); }

           // WPML
			$title = apply_filters('widget_title', empty($instance['title']) ? $title : $instance['title'], $instance );
			if (function_exists('icl_translate') && function_exists('icl_register_string')) {

				// VERSION < 3.3
				icl_register_string ('loc-belle-widgets-plugin', "$widget_id-widget[name]", $name);
				icl_register_string ('loc-belle-widgets-plugin', "$widget_id-widget[tagline]", $tagline);
				icl_register_string ('loc-belle-widgets-plugin', "$widget_id-widget[description]", $description);
				icl_register_string ('loc-belle-widgets-plugin', "$widget_id-widget[read_more_text]", $read_more_text);
				icl_register_string ('loc-belle-widgets-plugin', "$widget_id-widget[read_more_link]", $read_more_link);

				$name = icl_translate('loc-belle-widgets-plugin', "$widget_id-widget[name]", $name);
				$tagline = icl_translate('loc-belle-widgets-plugin', "$widget_id-widget[tagline]", $tagline);
				$description = icl_translate('loc-belle-widgets-plugin', "$widget_id-widget[description]", $description);
				$read_more_text = icl_translate('loc-belle-widgets-plugin', "$widget_id-widget[read_more_text]", $read_more_text);
				$read_more_link = icl_translate('loc-belle-widgets-plugin', "$widget_id-widget[read_more_link]", $read_more_link);
			
			} elseif (class_exists('SitePress')) {

				// VERSION > v3.3
				do_action('wpml_register_single_string', 'loc-belle-widgets-plugin', "$widget_id-widget[name]", $name);
				do_action('wpml_register_single_string', 'loc-belle-widgets-plugin', "$widget_id-widget[tagline]", $tagline);
				do_action('wpml_register_single_string', 'loc-belle-widgets-plugin', "$widget_id-widget[description]", $description);
				do_action('wpml_register_single_string', 'loc-belle-widgets-plugin', "$widget_id-widget[read_more_text]", $read_more_text);
				do_action('wpml_register_single_string', 'loc-belle-widgets-plugin', "$widget_id-widget[read_more_link]", $read_more_link);
				
				$name = apply_filters('wpml_translate_single_string', $name, 'loc-belle-widgets-plugin', "$widget_id-widget[name]");
				$tagline = apply_filters('wpml_translate_single_string', $tagline, 'loc-belle-widgets-plugin', "$widget_id-widget[tagline]");
				$description = apply_filters('wpml_translate_single_string', $description, 'loc-belle-widgets-plugin', "$widget_id-widget[description]");
				$read_more_text = apply_filters('wpml_translate_single_string', $read_more_text, 'loc-belle-widgets-plugin', "$widget_id-widget[read_more_text]");
				$read_more_link = apply_filters('wpml_translate_single_string', $read_more_link, 'loc-belle-widgets-plugin', "$widget_id-widget[read_more_link]");
			
			}

			?>

			<?php echo wp_kses_post($before_widget); ?>

			<?php if (!empty($title)) { echo wp_kses_post($before_title . $title . $after_title); } ?>

			<?php 

				// IMAGE
				if (!empty($image_url)) { printf('<img class="bio-feat-image" src="%s" alt="Author image" />', esc_url($image_url)); }

				// HEADING
				if (!empty($name) || !empty($tagline)) { echo '<div class="bio-feat-heading">'; }
				if (!empty($name)) { printf('<div>%s</div>', wp_kses_post($name)); }
				if (!empty($tagline)) { printf('<div>%s</div>', wp_kses_post($tagline)); }
				if (!empty($name) || !empty($tagline)) { echo '</div>'; }

				// DESCRIPTION
				if (!empty($description)) { printf('<div class="bio-desc">%s</div>', wp_kses_post($description)); }

				// READ MORE
				if (!empty($read_more_text) && !empty($read_more_link)) { printf('<a href="%s" class="read-more">%s</a>', esc_url($read_more_link), wp_kses_post($read_more_text)); }

				// SOCIAL LINKS
				if (canon_fw_get_author_social_links_list($user_id)) { printf('<div class="bio-social social-links">%s</div>', wp_kses_post(canon_fw_get_author_social_links_list($user_id))); }

			?>

			<?php echo wp_kses_post($after_widget); ?>


			<?php
		}

	} //END CLASS



