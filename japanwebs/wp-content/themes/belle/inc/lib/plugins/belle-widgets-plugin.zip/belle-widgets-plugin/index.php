<?php

/*
Plugin Name: Belle Widgets Plugin
Plugin URI: http://www.themecanon.com
Description: Custom widgets for Belle theme by Theme Canon.
Version: 1.0
Author: Theme Canon
Auhtor URI: http://www.themecanon.com
*/


/**************************************
NOTES

- Belle: More Posts.
This widget taps into the post meta: "post_views" to determine most popular posts by view. (NB: data not supplied by plugin).
This widget uses a custom field (post): "cmb_hide_from_popular". (NB: data not supplied by plugin).

***************************************/

/**************************************
INDEX

MAKE SHORTCODES EXECUTE IN WIDGET TEXTS
PLUGIN LOCALIZATION INIT
PHP INCLUDES
WP ENQUEUE
IMAGE SIZES
FACEBOOK PAGE PLUGIN MECHANICS

***************************************/


/**************************************
MAKE SHORTCODES EXECUTE IN WIDGET TEXTS
***************************************/

	add_filter('widget_text', 'do_shortcode');


/**************************************
PLUGIN LOCALIZATION INIT
***************************************/

	add_action('after_setup_theme', 'belle_widgets_plugin_localization_setup');
	function belle_widgets_plugin_localization_setup() {
	    load_plugin_textdomain('loc-belle-widgets-plugin', false,  dirname( plugin_basename( __FILE__ ) ) . '/languages/');
	}


/**************************************
PHP INCLUDES
***************************************/

	// include widgets
	include plugin_dir_path(__FILE__) . 'inc/widgets/widget_belle_more_posts.php';
	include plugin_dir_path(__FILE__) . 'inc/widgets/widget_belle_twitter.php';
	include plugin_dir_path(__FILE__) . 'inc/widgets/widget_belle_search.php';
	include plugin_dir_path(__FILE__) . 'inc/widgets/widget_belle_quicklinks.php';
	include plugin_dir_path(__FILE__) . 'inc/widgets/widget_belle_fact.php';
	include plugin_dir_path(__FILE__) . 'inc/widgets/widget_belle_statistics.php';
	include plugin_dir_path(__FILE__) . 'inc/widgets/widget_belle_single_post.php';
	include plugin_dir_path(__FILE__) . 'inc/widgets/widget_belle_quote.php';
	include plugin_dir_path(__FILE__) . 'inc/widgets/widget_belle_accordion.php';
	include plugin_dir_path(__FILE__) . 'inc/widgets/widget_belle_tabs.php';
	include plugin_dir_path(__FILE__) . 'inc/widgets/widget_belle_toggle.php';
	include plugin_dir_path(__FILE__) . 'inc/widgets/widget_belle_facebook.php';
	include plugin_dir_path(__FILE__) . 'inc/widgets/widget_belle_animated_number.php';
	include plugin_dir_path(__FILE__) . 'inc/widgets/widget_belle_paired_list.php';
	include plugin_dir_path(__FILE__) . 'inc/widgets/widget_belle_instagram_gallery.php';
	include plugin_dir_path(__FILE__) . 'inc/widgets/widget_belle_social_links.php';
	include plugin_dir_path(__FILE__) . 'inc/widgets/widget_belle_about.php';

	// conditional widgets. Notice the after_setup_theme action - this to prevent the class_exists check before all plugins have been loaded. If not in place the class_exists would just be executed when this plugin loads which could be before another plugin.
	add_action('after_setup_theme', 'load_conditional_widgets');
	function load_conditional_widgets() {
		// if (class_exists('Tribe__Events__Main')) { include 'inc/widgets/widget_belle_single_event.php'; }
	}




/**************************************
WP ENQUEUE
***************************************/

	//front end includes
	add_action('wp_enqueue_scripts','belle_widgets_plugin_load_to_front');
	function belle_widgets_plugin_load_to_front() {

		//front end scripts (js)
		wp_enqueue_script('belle-widgets-plugin-scripts', plugins_url('', __FILE__ ) . '/js/scripts.js', array(), false, true);
		wp_enqueue_script('belle-widgets-plugin-animatenumbers', plugins_url('', __FILE__ ) . '/js/jquery.animateNumbers.js', array(), false, true);
		wp_enqueue_script('belle-widgets-plugin-fittext', plugins_url('', __FILE__ ) . '/js/fittext.js', array(), false, true);

		//style (css)	
		wp_enqueue_style('belle-widgets-plugin-style', plugins_url('', __FILE__ ) . '/css/style.css');


	}

	//back end includes
	add_action('admin_enqueue_scripts', 'belle_widgets_plugin_load_to_back');  //this was changed to admin_enqueue_scripts from action hook admin_footer. Let's see if it makes a difference
	function belle_widgets_plugin_load_to_back() {

		//back end scripts (js)
		wp_enqueue_script('jquery');
		wp_enqueue_script('jquery-ui', false, array(), false, false);
		wp_enqueue_script('jquery-ui-sortable', false, array(), false, true);
		wp_enqueue_script('belle-widgets-plugin-admin-scripts', plugins_url('', __FILE__ ) . '/js/admin-scripts.js', array(), false, true);

		//style (css)	
		wp_enqueue_style('belle-widgets-plugin-admin-style', plugins_url('', __FILE__ ) . '/css/admin-style.css');

	}

/**************************************
IMAGE SIZES
***************************************/

	add_image_size( 'widget_more_posts_thumb', 970, 970, true);
	add_image_size( 'widget_more_posts_thumbnails_list_thumb', 400, 400, true);


/**************************************
FACEBOOK PAGE PLUGIN MECHANICS
***************************************/

	add_action('wp_footer', 'add_facebook_js');  
	function add_facebook_js () {
	?>
		<div id="fb-root"></div>
		<script>
			(function(d, s, id) {
			  var js, fjs = d.getElementsByTagName(s)[0];
			  if (d.getElementById(id)) return;
			  js = d.createElement(s); js.id = id;
			  js.src = "//connect.facebook.net/en_US/all.js#xfbml=1";
			  fjs.parentNode.insertBefore(js, fjs);
			}(document, 'script', 'facebook-jssdk'));
		</script>	
	<?php
	}