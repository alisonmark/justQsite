<?php

/*
Plugin Name: Belle Shortcodes Plugin
Plugin URI: http://www.themecanon.com
Description: Shortcodes plugin for Belle theme by Theme Canon.
Version: 1.0
Author: ThemeCanon
Auhtor URI: http://www.themecanon.com
*/



/**************************************
INDEX

INFO
PHP INCLUDES
WP ENQUEUE
PLUGIN LOCALIZATION INIT

***************************************/

/**************************************
INFO

Lightbox shortcodes are dependent upon fancybox which is not included in plugin.

***************************************/


/**************************************
PHP INCLUDES
***************************************/

	include plugin_dir_path(__FILE__) . 'inc/functions/shortcodes.php';


/**************************************
WP ENQUEUE
***************************************/

	//front end includes
	add_action('wp_enqueue_scripts','belle_shortcodes_plugin_load_to_front');
	function belle_shortcodes_plugin_load_to_front() {

		// scripts (js)
		wp_enqueue_script('belle-shortcodes-plugin-scripts', plugins_url('', __FILE__ ) . '/js/scripts.js', array(), false, true);
		wp_enqueue_script('belle-shortcodes-plugin-flexslider', plugins_url('', __FILE__ ) . '/js/jquery.flexslider-min.js', array(), false, true);
		
		//style (css)	
		wp_enqueue_style('belle-shortcodes-plugin-style', plugins_url('', __FILE__ ) . '/css/style.css');
		wp_enqueue_style('belle-shortcodes-plugin-flexslider-style', plugins_url('', __FILE__ ) . '/css/flexslider.css');
		
	}

	//back end includes
	add_action('admin_enqueue_scripts', 'belle_shortcodes_plugin_load_to_back');
	function belle_shortcodes_plugin_load_to_back() {

	}


/**************************************
PLUGIN LOCALIZATION INIT
***************************************/

	add_action('after_setup_theme', 'belle_shortcodes_plugin_localization_setup');
	function belle_shortcodes_plugin_localization_setup() {
	    load_plugin_textdomain('loc-belle-shortcodes-plugin', false,  dirname( plugin_basename( __FILE__ ) ) . '/languages/');
	}