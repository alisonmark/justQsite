<?php

/**************************************
CUSTOM META FIELD
***************************************/

	//metaboxes
	add_action('add_meta_boxes', 'register_cmb_cpt_poll');
	add_action ('save_post', 'update_cmb_cpt_poll');

	function register_cmb_cpt_poll () {
		add_meta_box('cmb_cpt_poll','Belle poll settings', 'display_cmb_cpt_poll','cpt_poll','normal','high');
	}

	function display_cmb_cpt_poll ($post) {

	/**************************************
	GET VALUES
	***************************************/

		// OPTIONS
		$default_somevariable = 90;

		// DEFAULTS
		$cmb_exist = get_post_meta($post->ID, 'cmb_exist', true);
		
		if (empty($cmb_exist)) {

			update_post_meta($post->ID, 'cmb_poll_header', 'checked');

			update_post_meta($post->ID, 'cmb_poll_answers', array(
				0	=>	array (
					'answer'		=> esc_html__('Answer 1', 'loc-belle-core-plugin'),
					'votes'			=> 0,
				),
				1	=>	array (
					'answer'		=> esc_html__('Answer 2', 'loc-belle-core-plugin'),
					'votes'			=> 0,
				),
				2	=>	array (
					'answer'		=> esc_html__('Answer 3', 'loc-belle-core-plugin'),
					'votes'			=> 0,
				),
			));

		}

		// GENERAL
		$cmb_poll_header = get_post_meta($post->ID, 'cmb_poll_header', true);

		// ANSWERS
		$cmb_poll_answers = get_post_meta($post->ID, 'cmb_poll_answers', true);


	/**************************************
	DISPLAY CONTENT
	***************************************/

		?>

		<div class="option_heading">
			<span><?php esc_html_e("Shortcode", "loc-belle-core-plugin"); ?></span>
		</div>

			<div class="option_item">

				<input type='text' class="poll-shortcode widefat" onclick="this.select()" value='[poll id="<?php echo esc_attr($post->ID); ?>"]' readonly>
			
			</div>

			<?php
				
				canon_fw_cmb_option(array(
					'type'					=> 'select',
					'title' 				=> esc_html__('Header', 'loc-belle-core-plugin'),
					'slug' 					=> 'cmb_poll_header',
					'select_options'		=> array(
						'standard'				=> esc_html__('Standard header', 'loc-belle-core-plugin'),
						'title'					=> esc_html__('Use title as header', 'loc-belle-core-plugin'),
						'off'				=> esc_html__('No header', 'loc-belle-core-plugin'),
					),
					'post_id'				=> $post->ID,
				)); 

							
			?>

		<div class="option_heading">
			<span><?php esc_html_e("Answers", "loc-belle-core-plugin"); ?></span>
		</div>

			<div class="option_item poll-answers cmb-ul-sortable">

				<ul class="ul_sortable" data-split_index="1">

					<?php
						
						for ($i = 0; $i < count($cmb_poll_answers); $i++) {  
						?>

							<li>
								<label><?php esc_html_e("Answer", "loc-belle-core-plugin"); ?></label>
								<input type='text' name="cmb_poll_answers[<?php echo esc_attr($i); ?>][answer]" class="li_option poll-answer" value="<?php if (!empty($cmb_poll_answers[$i]['answer'])) { echo htmlspecialchars($cmb_poll_answers[$i]['answer']); } ?>">
								
								<label><?php esc_html_e("Votes", "loc-belle-core-plugin"); ?> </label>
								<input 
									type='number' 
									name="cmb_poll_answers[<?php echo esc_attr($i); ?>][votes]" 
									class="li_option poll-votes" 
									value="<?php if (isset($cmb_poll_answers[$i]['votes'])) { echo esc_attr($cmb_poll_answers[$i]['votes']); } ?>"
								>
								
								<button type="button" class="button ul_del_this float-right"><?php esc_html_e("delete", "loc-belle-core-plugin"); ?></button>
							</li>
							
						<?php
						}
					
					?>
				</ul>

				<div class="ul_control" data-min="2" data-max="1000">
					<input type="button" class="button ul_add" value="<?php esc_html_e("Add", "loc-belle-core-plugin"); ?>" />
				</div>


			</div>




		<!-- add nonce -->
		<input type="hidden" name="cmb_nonce" value="<?php echo wp_create_nonce(basename(__FILE__)); ?>" />
		<input type="hidden" name="cmb_exist" value="true" />




		<?php	
	}



/**************************************
UPDATE
***************************************/

	function update_cmb_cpt_poll ($post_id) {
		// avoid activation on irrelevant admin pages
		if (!isset($_POST['cmb_nonce'])) {
			return false;		
		}

		// verify nonce.    
		if (!wp_verify_nonce($_POST['cmb_nonce'], basename(__FILE__)) || !isset($_POST['cmb_nonce'])) {
			return false;
		}

		if(defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) {
			return;
		} else {

		// ARRAY VALUES
			if (isset($_POST['cmb_poll_answers'])) { $_POST['cmb_poll_answers'] = array_values($_POST['cmb_poll_answers']); }

		// GENERAL
			if (isset($_POST['cmb_poll_header'])) { update_post_meta($post_id, 'cmb_poll_header', $_POST['cmb_poll_header']); } else { update_post_meta($post_id, 'cmb_poll_header', null); };
				
		// ANSWERS
			if (isset($_POST['cmb_poll_answers'])) { update_post_meta($post_id, 'cmb_poll_answers', $_POST['cmb_poll_answers']); } else { update_post_meta($post_id, 'cmb_poll_answers', null); };
				
			if (isset($_POST['cmb_exist'])) { update_post_meta($post_id, 'cmb_exist', $_POST['cmb_exist']); } else { update_post_meta($post_id, 'cmb_exist', null); };
		}
	}


