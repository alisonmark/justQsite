<?php

/**************************************
INDEX

REGISTER CUSTOM POST FORMAT: POLL
CUSTOM MESSAGES: POLL
CUSTOM TAXONOMIES: POLL CATEGORY
CUSTOM EDIT.PHP COLUMNS

***************************************/


/**************************************
REGISTER CUSTOM POST FORMAT: POLL
***************************************/

add_action( 'init', 'canon_register_cpt_poll' );

function canon_register_cpt_poll() {

	$labels = array(
		'name'               	=> esc_html__( 'Polls', 'loc-belle-core-plugin' ),
		'singular_name'      	=> esc_html__( 'Poll', 'loc-belle-core-plugin' ),
		'add_new'            	=> esc_html__( 'Add New', 'loc-belle-core-plugin' ),
		'add_new_item'       	=> esc_html__( 'Add New Poll', 'loc-belle-core-plugin' ),
		'edit_item'          	=> esc_html__( 'Edit Poll', 'loc-belle-core-plugin' ),
		'new_item'           	=> esc_html__( 'New Poll', 'loc-belle-core-plugin' ),
		'all_items'          	=> esc_html__( 'All Polls', 'loc-belle-core-plugin' ),
		'view_item'          	=> esc_html__( 'View Poll', 'loc-belle-core-plugin' ),
		'search_items'       	=> esc_html__( 'Search Polls', 'loc-belle-core-plugin' ),
		'not_found'          	=> esc_html__( 'No polls found', 'loc-belle-core-plugin' ),
		'not_found_in_trash' 	=> esc_html__( 'No polls found in the Trash', 'loc-belle-core-plugin' ), 
		'parent_item_colon'  	=> '',
		'menu_name'          	=> esc_html__('Polls', 'loc-belle-core-plugin'),
	);

	$args = array(
		'labels'        		=> $labels,
		'description'   		=> 'Holds our polls and poll specific data',
		'public'        		=> true,
		'menu_position' 		=> 5,
		'supports'      		=> array( 'title', 'editor' ),
		'has_archive'   		=> false,
		'show_in_nav_menus'		=> false,
		'exclude_from_search' 	=> true,
		'rewrite' 				=> array('slug' => 'polls'),
	);

	register_post_type( 'cpt_poll', $args );	
}

/**************************************
CUSTOM MESSAGES:POLL
***************************************/

add_filter( 'post_updated_messages', 'canon_cpt_poll_messages' );

function canon_cpt_poll_messages($messages) {
	global $post, $post_ID;

	$messages['cpt_poll'] = array(
		0 => '', 
		1 => sprintf( wp_kses_post(__('Poll updated. <a href="%s">View poll</a>', 'loc-belle-core-plugin')), esc_url( get_permalink($post_ID) ) ),
		2 => esc_html__('Custom field updated.', 'loc-belle-core-plugin'),
		3 => esc_html__('Custom field deleted.', 'loc-belle-core-plugin'),
		4 => esc_html__('Poll updated.', 'loc-belle-core-plugin'),
		5 => isset($_GET['revision']) ? sprintf( esc_html__('Poll restored to revision from %s', 'loc-belle-core-plugin'), wp_post_revision_title( (int) $_GET['revision'], false ) ) : false,
		6 => sprintf( wp_kses_post(__('Poll published. <a href="%s">View poll</a>')), esc_url( get_permalink($post_ID) ), 'loc-belle-core-plugin' ),
		7 => esc_html__('Poll saved.', 'loc-belle-core-plugin'),
		8 => sprintf( wp_kses_post(__('Poll submitted. <a target="_blank" href="%s">Preview poll</a>', 'loc-belle-core-plugin')), esc_url( add_query_arg( 'preview', 'true', get_permalink($post_ID) ) ) ),
		9 => sprintf( wp_kses_post(__('Poll scheduled for: <strong>%1$s</strong>. <a target="_blank" href="%2$s">Preview poll</a>', 'loc-belle-core-plugin')), date_i18n(__( 'M j, Y @ G:i', 'loc-belle-core-plugin' ), strtotime( $post->post_date ) ), esc_url( get_permalink($post_ID) ) ),
		10 => sprintf( wp_kses_post(__('Poll draft updated. <a target="_blank" href="%s">Preview poll</a>', 'loc-belle-core-plugin')), esc_url( add_query_arg( 'preview', 'true', get_permalink($post_ID) ) ) ),
	);

	return $messages;
}

/**************************************
CUSTOM TAXONOMIES: POLL CATEGORY
***************************************/

add_action( 'init', 'canon_register_taxonomy_poll_category', 0 );

function canon_register_taxonomy_poll_category () {
	$labels = array(
		'name'              => esc_html__( 'Poll Categories', 'loc-belle-core-plugin' ),
		'singular_name'     => esc_html__( 'Poll Category', 'loc-belle-core-plugin' ),
		'search_items'      => esc_html__( 'Search Poll Categories', 'loc-belle-core-plugin' ),
		'all_items'         => esc_html__( 'All Poll Categories', 'loc-belle-core-plugin' ),
		'parent_item'       => esc_html__( 'Parent Poll Category', 'loc-belle-core-plugin' ),
		'parent_item_colon' => esc_html__( 'Parent Poll Category:', 'loc-belle-core-plugin' ),
		'edit_item'         => esc_html__( 'Edit Poll Category', 'loc-belle-core-plugin' ), 
		'update_item'       => esc_html__( 'Update Poll Category', 'loc-belle-core-plugin' ),
		'add_new_item'      => esc_html__( 'Add New Poll Category', 'loc-belle-core-plugin' ),
		'new_item_name'     => esc_html__( 'New Poll Category', 'loc-belle-core-plugin' ),
		'menu_name'         => esc_html__( 'Poll Categories', 'loc-belle-core-plugin' ),
	);
	$args = array(
		'labels' 			=> $labels,
		'hierarchical' 		=> true,
		'show_in_nav_menus'	=> false,
	);
	register_taxonomy( 'poll_category', 'cpt_poll', $args );
}


/**************************************
CUSTOM EDIT.PHP COLUMNS
***************************************/


// first add the custom columns
add_filter('manage_edit-cpt_poll_columns', 'add_cpt_poll_columns', 4);
function add_cpt_poll_columns($defaults){

	$defaults['poll_category'] = esc_html__('Poll Categories', 'loc-belle-core-plugin');
	return $defaults;

}

// now fill custom columns with actual data
add_action('manage_posts_custom_column', 'fill_cpt_poll_columns', 4, 2);
function fill_cpt_poll_columns($column, $post_id){

	if($column === 'poll_category'){
		// get terms and sort
		$terms = get_the_terms($post_id, 'poll_category');
		if ($terms) {
			$terms = array_values($terms);
			// output terms with links
			for ($i = 0; $i < count($terms); $i++) {  
				printf('<a href="?post_type=cpt_poll&poll_category=%s">%s</a>', $terms[$i]->slug, $terms[$i]->name);
				if ($i !== count($terms)-1 ) { echo ", "; }	// add comma separator unless it is the last item
			}
		}
	}

}