<?php

/**************************************
INDEX

GENERAL:
The custom post type base name should be singular (cpt_project - not cpt_projects)

REPLACE:
TEMPLATECAPS
templatelowercase
Templatefirstcap
templateslug (usually: namespace_templatelowercase e.g. cpt_project)
FOLDERNAME
loc-belle-core-plugin


REGISTER CUSTOM POST FORMAT: TEMPLATECAPS
CUSTOM MESSAGES: TEMPLATECAPS
CUSTOM TAXONOMIES: TEMPLATECAPS CATEGORY

***************************************/


/**************************************
REGISTER CUSTOM POST FORMAT: TEMPLATECAPS
***************************************/

add_action( 'init', 'canon_register_cpt_templatelowercases' );

function canon_register_cpt_templatelowercases() {

	$labels = array(
		'name'               	=> _x( 'Templatefirstcaps', 'post type general name', 'loc-belle-core-plugin' ),
		'singular_name'      	=> _x( 'Templatefirstcap', 'post type singular name', 'loc-belle-core-plugin' ),
		'add_new'            	=> _x( 'Add New', 'book', 'loc-belle-core-plugin' ),
		'add_new_item'       	=> esc_html__( 'Add New Templatefirstcap', 'loc-belle-core-plugin' ),
		'edit_item'          	=> esc_html__( 'Edit Templatefirstcap', 'loc-belle-core-plugin' ),
		'new_item'           	=> esc_html__( 'New Templatefirstcap', 'loc-belle-core-plugin' ),
		'all_items'          	=> esc_html__( 'All Templatefirstcaps', 'loc-belle-core-plugin' ),
		'view_item'          	=> esc_html__( 'View Templatefirstcap', 'loc-belle-core-plugin' ),
		'search_items'       	=> esc_html__( 'Search Templatefirstcaps', 'loc-belle-core-plugin' ),
		'not_found'          	=> esc_html__( 'No templatelowercases found', 'loc-belle-core-plugin' ),
		'not_found_in_trash' 	=> esc_html__( 'No templatelowercases found in the Trash', 'loc-belle-core-plugin' ), 
		'parent_item_colon'  	=> '',
		'menu_name'          	=> 'FOLDERNAME'
	);

	$args = array(
		'labels'        		=> $labels,
		'description'   		=> 'Holds our templatelowercases and templatelowercase specific data',
		'public'        		=> true,
		'menu_position' 		=> 5,
		'supports'      		=> array( 'title', 'editor', 'thumbnail', 'excerpt', 'comments' ),
		'has_archive'   		=> true,
		'rewrite' 				=> array('slug' => 'templatelowercases'),
		// 'exclude_from_search' 	=> true,
	);

	register_post_type( 'templateslug', $args );	
}

/**************************************
CUSTOM MESSAGES:TEMPLATECAPS
***************************************/

add_filter( 'post_updated_messages', 'canon_cpt_templatelowercases_messages' );

function canon_cpt_templatelowercases_messages($messages) {
	global $post, $post_ID;

	$messages['templateslug'] = array(
		0 => '', 
		1 => sprintf( wp_kses_post(__('Templatefirstcap updated. <a href="%s">View templatelowercase</a>')), esc_url( get_permalink($post_ID), 'loc-belle-core-plugin' ) ),
		2 => esc_html__('Custom field updated.', 'loc-belle-core-plugin'),
		3 => esc_html__('Custom field deleted.', 'loc-belle-core-plugin'),
		4 => esc_html__('Templatefirstcap updated.', 'loc-belle-core-plugin'),
		5 => isset($_GET['revision']) ? sprintf( esc_html__('Templatefirstcap restored to revision from %s', 'loc-belle-core-plugin'), wp_post_revision_title( (int) $_GET['revision'], false ) ) : false,
		6 => sprintf( wp_kses_post(__('Templatefirstcap published. <a href="%s">View templatelowercase</a>')), esc_url( get_permalink($post_ID) ), 'loc-belle-core-plugin' ),
		7 => esc_html__('Templatefirstcap saved.', 'loc-belle-core-plugin'),
		8 => sprintf( wp_kses_post(__('Templatefirstcap submitted. <a target="_blank" href="%s">Preview templatelowercase</a>', 'loc-belle-core-plugin')), esc_url( add_query_arg( 'preview', 'true', get_permalink($post_ID) ) ) ),
		9 => sprintf(wp_kses_post(__('Templatefirstcap scheduled for: <strong>%1$s</strong>. <a target="_blank" href="%2$s">Preview templatelowercase</a>', 'loc-belle-core-plugin')), date_i18n( esc_html__( 'M j, Y @ G:i', 'loc-belle-core-plugin' ), strtotime( $post->post_date ) ), esc_url( get_permalink($post_ID) ) ),
		10 => sprintf( wp_kses_post(__('Templatefirstcap draft updated. <a target="_blank" href="%s">Preview templatelowercase</a>', 'loc-belle-core-plugin')), esc_url( add_query_arg( 'preview', 'true', get_permalink($post_ID) ) ) ),
	);

	return $messages;
}

/**************************************
CUSTOM TAXONOMIES: TEMPLATECAPS CATEGORY
***************************************/

add_action( 'init', 'canon_register_taxonomy_templatelowercase_category', 0 );

function canon_register_taxonomy_templatelowercase_category () {
	$labels = array(
		'name'              => _x( 'Templatefirstcap Categories', 'taxonomy general name', 'loc-belle-core-plugin' ),
		'singular_name'     => _x( 'Templatefirstcap Category', 'taxonomy singular name', 'loc-belle-core-plugin' ),
		'search_items'      => esc_html__( 'Search Templatefirstcap Categories', 'loc-belle-core-plugin' ),
		'all_items'         => esc_html__( 'All Templatefirstcap Categories', 'loc-belle-core-plugin' ),
		'parent_item'       => esc_html__( 'Parent Templatefirstcap Category', 'loc-belle-core-plugin' ),
		'parent_item_colon' => esc_html__( 'Parent Templatefirstcap Category:', 'loc-belle-core-plugin' ),
		'edit_item'         => esc_html__( 'Edit Templatefirstcap Category', 'loc-belle-core-plugin' ), 
		'update_item'       => esc_html__( 'Update Templatefirstcap Category', 'loc-belle-core-plugin' ),
		'add_new_item'      => esc_html__( 'Add New Templatefirstcap Category', 'loc-belle-core-plugin' ),
		'new_item_name'     => esc_html__( 'New Templatefirstcap Category', 'loc-belle-core-plugin' ),
		'menu_name'         => esc_html__( 'Templatefirstcap Categories', 'loc-belle-core-plugin' ),
	);
	$args = array(
		'labels' => $labels,
		'hierarchical' => true,
	);
	register_taxonomy( 'templatelowercase_category', 'templateslug', $args );
}
