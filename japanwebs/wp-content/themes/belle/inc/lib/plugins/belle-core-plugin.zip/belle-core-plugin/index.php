<?php

/*
Plugin Name: Belle Core Plugin
Plugin URI: http://www.themecanon.com
Description: Core functionality plugin for Belle theme by Theme Canon.
Version: 1.0
Author: ThemeCanon
Auhtor URI: http://www.themecanon.com
*/



/**************************************
INDEX

PHP INCLUDES
WP ENQUEUE
PLUGIN LOCALIZATION INIT
EXCLUDE THEME FROM REPOSITORY UPDATE CHECK

***************************************/



/**************************************
PHP INCLUDES
***************************************/

	// custom post types and custom meta boxes
	include plugin_dir_path(__FILE__) . 'inc/functions/functions_register_cpt_poll.php';
	include plugin_dir_path(__FILE__) . 'inc/functions/functions_cmb_pages.php';
	include plugin_dir_path(__FILE__) . 'inc/functions/functions_cmb_posts.php';
	include plugin_dir_path(__FILE__) . 'inc/functions/functions_cmb_cpt_poll.php';


/**************************************
WP ENQUEUE
***************************************/

	//front end includes
	add_action('wp_enqueue_scripts','belle_core_plugin_load_to_front');
	function belle_core_plugin_load_to_front() {
	}

	//back end includes
	add_action('admin_enqueue_scripts', 'belle_core_plugin_load_to_back');
	function belle_core_plugin_load_to_back() {

		//scripts (js)
		wp_enqueue_script('belle-core-plugin-admin-scripts', plugins_url('', __FILE__ ) . '/js/admin-scripts.js', array(), false, true);

		//style (css)	
		wp_enqueue_style('belle-core-plugin-stylesheet', plugins_url('', __FILE__ ) . '/css/style.css');

	}


/**************************************
PLUGIN LOCALIZATION INIT
***************************************/

	add_action('after_setup_theme', 'belle_core_plugin_localization_setup');
	function belle_core_plugin_localization_setup() {
	    load_plugin_textdomain('loc-belle-core-plugin', false,  dirname( plugin_basename( __FILE__ ) ) . '/languages/');
	}

 

/**************************************
EXCLUDE THEME FROM REPOSITORY UPDATE CHECK

NB: This snippet is present both in theme and in core plugin as redundancy failsafe. Remember to update both on edit.
***************************************/

	add_filter( 'http_request_args', 'canon_belle_exclude_theme_from_repository_update_check', 5, 2 );

	if (!function_exists("canon_belle_exclude_theme_from_repository_update_check")) { function canon_belle_exclude_theme_from_repository_update_check($r, $url) {	

	    // bounce if not a theme update request
	    if (strpos($url, '//api.wordpress.org/themes/update-check' ) === false ) { return $r; } 

	    $themes = json_decode($r['body']['themes'], true);
	    unset($themes['themes']['belle']);
	    $r['body']['themes'] = json_encode( $themes );

	    return $r;
	}}
	 

